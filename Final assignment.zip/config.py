from dotenv import load_dotenv
import os

# Load .env (if present)
load_dotenv()

# Mongo connection URI and DB name
MONGODB_URI = os.getenv("MONGODB_URI")
DB_NAME      = os.getenv("DB_NAME")
