import pandas as pd
import matplotlib.pyplot as plt

# Load the survey data
df = pd.read_csv('survey_responses.csv')

# Visualization 1: Bar chart of average income by age
avg_income = df.groupby('age')['income'].mean()

plt.figure()
avg_income.plot(kind='bar')
plt.title('Average Income by Age')
plt.xlabel('Age')
plt.ylabel('Average Income (USD)')
plt.tight_layout()
plt.savefig('avg_income_by_age.png')
plt.show()

# Visualization 2: Histogram of spending by gender
expense_cols = ['utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']
avg_spend = df.groupby('gender')[expense_cols].mean().T

plt.figure()
avg_spend.plot(kind='bar')
plt.title('Average Spending by Category and Gender')
plt.xlabel('Expense Category')
plt.ylabel('Average Spending (USD)')
plt.legend(title='Gender')
plt.tight_layout()
plt.savefig('spending_by_gender.png')
plt.show()