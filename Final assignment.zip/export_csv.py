import argparse
import logging
import sys

import pandas as pd
from pymongo import MongoClient, errors

import config


class SurveyDataExporter:
    def __init__(self, uri: str, db_name: str, collection: str = "users"):
        try:
            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
            # Trigger server selection to catch invalid URI / connectivity early
            self.client.admin.command('ping')
        except errors.PyMongoError as e:
            logging.error("Could not connect to MongoDB: %s", e)
            sys.exit(1)

        self.db   = self.client[db_name]
        self.coll = self.db[collection]

    def fetch_all(self) -> list[dict]:
        """Fetch all documents from the collection."""
        try:
            return list(self.coll.find())
        except errors.PyMongoError as e:
            logging.error("Error fetching data from MongoDB: %s", e)
            sys.exit(1)

    def to_dataframe(self, docs: list[dict]) -> pd.DataFrame:
        """
        Convert list of Mongo documents to a pandas DataFrame,
        flattening nested 'expenses' fields into top-level columns.
        """
        if not docs:
            logging.warning("No documents found in MongoDB.")
            return pd.DataFrame()

        # json_normalize will create columns like 'expenses.utilities'
        df = pd.json_normalize(docs)

        # Drop MongoDB internal fields
        for col in ["_id", "__v"]:
            if col in df.columns:
                df.drop(columns=[col], inplace=True)

        # Rename any 'expenses.*' columns by stripping the prefix
        new_cols = {
            col: col.replace("expenses.", "")
            for col in df.columns
            if col.startswith("expenses.")
        }
        df.rename(columns=new_cols, inplace=True)

        return df

    def export_to_csv(self, df: pd.DataFrame, path: str):
        """Write DataFrame to CSV."""
        if df.empty:
            logging.info("DataFrame is empty; no CSV will be written.")
            return
        try:
            df.to_csv(path, index=False)
            logging.info("Exported %d records to %s", len(df), path)
        except Exception as e:
            logging.error("Error writing CSV: %s", e)
            sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Export survey data from MongoDB to CSV")
    parser.add_argument(
        "-o", "--output",
        default="survey_responses.csv",
        help="Path to output CSV file (default: %(default)s)"
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    exporter = SurveyDataExporter(config.MONGODB_URI, config.DB_NAME)
    docs     = exporter.fetch_all()
    df       = exporter.to_dataframe(docs)
    exporter.export_to_csv(df, args.output)


if __name__ == "__main__":
    main()
