# 📝 Final Assignment: Survey Tool for Income Spending Analysis

## 📌 Overview

This Flask-based web application collects participants' income and spending data for a healthcare industry product launch. Data is stored in MongoDB, processed using Python, and visualized in Jupyter Notebook.

---

## 🌐 Live Deployment

🔗 http://56.228.33.60:5000/

> ⚠️ This app is temporarily open to all IPs (`0.0.0.0/0`) for evaluation purposes.  
> In production, restrict access to trusted IPs and enforce HTTPS using an Application Load Balancer (ALB) and an ACM-issued TLS certificate.

The live Flask app deployed on AWS is intended for data collection only.
Features like CSV export and data visualizations are performed locally in a Jupyter notebook, as per assignment instructions. These steps are demonstrated in the accompanying notebook.ipynb file.

Why this separation?
Hosting visual analytics and CSV export via a web app in production would require additional security, authentication, and frontend effort. For now, this separation ensures clean architecture and keeps the AWS deployment lightweight and focused.

---

## 📂 Features

- Collects user inputs:
  - Age
  - Gender
  - Total Income
  - Expense categories (utilities, entertainment, school fees, shopping, healthcare) with textboxes
- Stores data in MongoDB
- Implements a Python class `User` for processing
- Exports data to CSV
- Loads data in a Jupyter notebook for visualization

---

## 📊 Visualizations

Included in the Jupyter Notebook:
- **Bar chart**: Ages with the highest income
- **Pie/Donut chart**: Gender distribution across spending categories

Charts are exported for PowerPoint presentation use.

---

## 🧰 Technology Stack

- Python 3.12
- Flask 3.1.1
- MongoDB Atlas
- Pandas, Matplotlib
- Docker, AWS ECS (Fargate), CloudWatch

---

## 🛠️ How to Run Locally

1. Clone the repository or unzip the folder.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Create a `.env` file in the root directory:
   ```dotenv
   MONGODB_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/Learning
   DB_NAME=Learning
   ```
4. Run the app:
   ```bash
   python app.py
   ```

---

## 📦 How to Build & Deploy via Docker

Build locally:
```bash
docker build -t finalassignment:secure.
docker run -p 5000:5000 --env-file .env finalassignment:secure
```

Deploy to AWS ECS:
- Build and push Docker image to AWS ECR
- Create ECS Fargate service with public subnet and open port 5000

---

## 📁 Submission Structure

```
📦 FinalAssignment/
├── app.py
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env              # (excluded from repo, provide template only)
├── user.py
├── survey.csv
├── analysis.ipynb
├── README.md
```