import uuid

class User:
    def __init__(self, age, gender, income, expenses):
        self.id        = str(uuid.uuid4())
        self.age       = age
        self.gender    = gender
        self.income    = income
        self.expenses  = expenses

    def to_dict(self):
        return {
            "_id":       self.id,
            "age":       self.age,
            "gender":    self.gender,
            "income":    self.income,
            "expenses":  self.expenses
        }
