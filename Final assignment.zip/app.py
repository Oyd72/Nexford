from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from models import User
import config

# set up Mongo
client = MongoClient(config.MONGODB_URI)
db     = client[config.DB_NAME]
users  = db.users

app = Flask(__name__)

app.config['PROPAGATE_EXCEPTIONS'] = True
app.logger.setLevel('DEBUG')


@app.route('/', methods=['GET', 'POST'])
def survey():
    if request.method == 'POST':
        # Parse form inputs
        age    = int(request.form['age'])
        gender = request.form['gender']
        income = float(request.form['income'])

        # Collect expenses
        expenses = {}
        for category in ['utilities','entertainment','school_fees','shopping','healthcare']:
            if request.form.get(category):
                expenses[category] = float(request.form.get(f"{category}_amount", 0))

        # Save to Mongo
        user = User(age, gender, income, expenses)
        users.insert_one(user.to_dict())

        # After saving, redirect to our new thank-you page
        return redirect(url_for('thank_you'))

    # On GET, just show the form
    return render_template('survey_form.html')


@app.route('/thankyou', methods=['GET'])
def thank_you():
    # Render a template that asks: “Submit another?”
    return render_template('thankyou.html')


@app.route('/goodbye', methods=['GET'])
def goodbye():
    # Final page when user opts out of another submission
    return render_template('goodbye.html')


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
    
