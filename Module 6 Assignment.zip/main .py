
import numpy as np
import random
import os
import matplotlib.pyplot as plt
from keras import Input
from keras.datasets import fashion_mnist
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from keras.utils import to_categorical
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

def main():
    # Load Fashion MNIST dataset
    (x_train, y_train), (x_test, y_test) = fashion_mnist.load_data()

    # Normalize and reshape input data
    x_train = x_train.reshape(-1, 28, 28, 1).astype("float32") / 255
    x_test = x_test.reshape(-1, 28, 28, 1).astype("float32") / 255

    # One-hot encode target labels for training
    y_train_cat = to_categorical(y_train)
    y_test_cat = to_categorical(y_test)

    # Define the CNN model
    model = Sequential([
        Input(shape=(28, 28, 1)),
        Conv2D(32, (3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(10, activation='softmax')
    ])

    # Compile the model
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

    # Train the model
    model.fit(x_train, y_train_cat, epochs=5, batch_size=64, validation_split=0.1)

    # Evaluate on the test set
    loss, acc = model.evaluate(x_test, y_test_cat)
    print(f"\nTest Accuracy: {acc:.2f}")

    # Create output directory if not exists
    os.makedirs("images", exist_ok=True)

    # Label map for Fashion MNIST classes
    label_names = [
        "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
        "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
    ]

    # Predict and save two, randomly selected test image predictions
    random_indices = random.sample(range(len(x_test)), 2)

    for i, idx in enumerate(random_indices):
        img = x_test[idx].reshape(1, 28, 28, 1)
        prediction = model.predict(img)
        label = np.argmax(prediction)
        class_name = label_names[label]

        plt.imshow(x_test[idx].reshape(28, 28), cmap='gray')
        plt.title(f"Predicted: {class_name} ({label})")
        plt.axis('off')
        plt.savefig(f"images/prediction{i+1}_random.png")
        plt.show()

    # Predict all test images
    predictions = model.predict(x_test)
    predicted_labels = np.argmax(predictions, axis=1)
    true_labels = y_test  # Use original labels

    # Create and plot confusion matrix
    cm = confusion_matrix(true_labels, predicted_labels)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=label_names)
    fig, ax = plt.subplots(figsize=(10, 8))
    cbar = disp.plot(cmap='Blues', xticks_rotation=45, ax=ax, colorbar=True)
    colorbar = cbar.figure_.axes[-1]
    colorbar.set_yticks(list(colorbar.get_yticks()) + [1000])
    colorbar.set_yticklabels([int(tick) for tick in colorbar.get_yticks()[:-1]] + ['1000'])

    plt.title("Confusion Matrix - Fashion MNIST")
    plt.tight_layout()
    plt.savefig("images/confusion_matrix.png")
    plt.show()

if __name__ == "__main__":
    main()
