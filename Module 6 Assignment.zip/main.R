library(keras)
library(caret)
library(ggplot2)

# Load and normalize data
fashion <- dataset_fashion_mnist()

x_train <- fashion$train$x / 255
y_train <- to_categorical(fashion$train$y, 10)

x_test <- fashion$test$x / 255
y_test <- to_categorical(fashion$test$y, 10)

# Reshape input to 4D tensors (samples, height, width, channels)
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
x_test  <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))

# Build CNN model
model <- keras_model_sequential() %>%
  layer_conv_2d(
    filters = 32,
    kernel_size = c(3, 3),
    activation = "relu",
    input_shape = c(28, 28, 1)
  ) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(
    filters = 64,
    kernel_size = c(3, 3),
    activation = "relu"
  ) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 10, activation = "softmax")

# Compile model
model %>% compile(
  loss = "categorical_crossentropy",
  optimizer = optimizer_adam(),
  metrics = "accuracy"
)

# Train model
model %>% fit(
  x_train,
  y_train,
  epochs = 5,
  batch_size = 64,
  validation_split = 0.1
)

# Evaluate on test set
model %>% evaluate(x_test, y_test)

# Create output directory if it doesn't exist
if (!dir.exists("images")) {
  dir.create("images")
}

# Label map
label_names <- c(
  "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
  "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
)

# Predict and visualize two random test images
set.seed(123)
indices <- sample(seq_len(nrow(x_test)), 2)

for (i in seq_along(indices)) {
  idx <- indices[i]
  img <- x_test[idx, , , , drop = FALSE]
  pred <- model %>% predict(img)
  label <- which.max(pred) - 1
  class_name <- label_names[label + 1]

  # Show in RStudio Viewer first
  image(
    matrix(x_test[idx, , , 1], 28, 28)[, 28:1],
    col = gray.colors(255),
    main = paste("Predicted:", class_name, "(", label, ")")
  )

  # Then save to file
  png_filename <- paste0("images/prediction", i, "_r.png")
  png(png_filename)
  image(
    matrix(x_test[idx, , , 1], 28, 28)[, 28:1],
    col = gray.colors(255),
    main = paste("Predicted:", class_name, "(", label, ")")
  )
  dev.off()
}

# Predict on all test data
pred_probs <- model %>% predict(x_test)
predicted_labels <- apply(pred_probs, 1, which.max) - 1
true_labels <- apply(y_test, 1, which.max) - 1

# Create confusion matrix
cm <- confusionMatrix(
  factor(predicted_labels, levels = 0:9, labels = label_names),
  factor(true_labels, levels = 0:9, labels = label_names)
)

# Print confusion matrix summary
print(cm)

# Plot confusion matrix
cm_table <- as.data.frame(cm$table)
colnames(cm_table) <- c("Prediction", "Reference", "Freq")

ggplot(data = cm_table, aes(x = Reference, y = Prediction, fill = Freq)) +
  geom_tile(color = "white") +
  geom_text(aes(label = Freq), color = "black", size = 4) +
  scale_fill_gradient(low = "white", high = "steelblue") +
  labs(
    title = "Confusion Matrix - Fashion MNIST",
    x = "Actual Label",
    y = "Predicted Label"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Save confusion matrix plot
ggsave("images/confusion_matrix_r.png", width = 8, height = 6)