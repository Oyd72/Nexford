
# Fashion MNIST CNN Classifier

## 🎯 Objective

This project implements a Convolutional Neural Network (CNN) to classify images from the Fashion MNIST dataset. It demonstrates training, evaluation, prediction, and visualization of both individual predictions and a confusion matrix.

---

## 🛠️ How to Run

### Python

1. Create a virtual environment and activate it:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the main script:
   ```bash
   python main.py
   ```

4. Outputs:
   - Accuracy score
   - `images/prediction1_random.png` and `images/prediction2_random.png`
   - `images/confusion_matrix.png`

---

## 📊 Confusion Matrix

- A confusion matrix is generated and saved after testing.
- It visualizes model performance and shows misclassifications.
- Tick mark `1000` is added on the color bar to represent test set size.

---

## 📈 R Version Available

See the corresponding R script for a tidyverse + keras implementation, including ggplot-based confusion matrix: `main.R`
