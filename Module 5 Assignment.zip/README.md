# Breast Cancer PCA Analysis

## 🎯 Objective

This project applies **Principal Component Analysis (PCA)** to the breast cancer dataset from `sklearn.datasets` to reduce dimensionality and identify key patterns in the data. It also demonstrates how well two principal components can separate malignant and benign tumors, and includes a bonus logistic regression model for prediction.

---

## 🛠️ How to Run

1. Install required packages:
   ```bash
   pip install pandas scikit-learn matplotlib
   ```

2. Run the script:
   ```bash
   python main.py
   ```

3. Output:
   - Console will show data summaries and model performance
   - A plot file `pca_scatter.png` will be generated showing PCA results
   - Another plot file `Logistic Regression Decision Boundary (PCA Components)` will be generated to show the decision boundary the logistic regression model is drawing

---

## 📊 Summary of Results

- **Dataset shape**: 569 samples, 30 numeric features
- **Missing values**: None
- **PCA results**:
  - PC1 explains 44.27% of the variance
  - PC2 explains 18.97%
  - Combined: **63.24% of the data's structure retained**
- **Logistic regression accuracy**: **99.12%** using only the two PCA components

---

## 🖼️ PCA Graph Interpretation

The scatter plot `pca_scatter.png` shows the tumor samples projected onto the first two principal components:

- **Each point** represents a tumor sample
- **Red = malignant**, **Blue = benign**
- **PC1 (x-axis)** is influenced mostly by `mean concave points`
- **PC2 (y-axis)** reflects `mean fractal dimension`

### Insights:
- There is **clear visual separation** between malignant and benign tumors.
- This suggests that a few carefully chosen features (or dimensions) can **effectively distinguish tumor types**.
- **Outliers** and mixed points represent ambiguous or atypical cases — useful for deeper diagnostic investigation.
- The PCA graph provides **diagnostic confidence** that key feature patterns are linked to tumor classification.

---

## ✅ Files Included

| File | Description |
|------|-------------|
| `main.py` | Main script: loads data, applies PCA, trains logistic regression |
| `README.md` | This file — explains how to use and interpret the project |

---

## 📌 Notes

- PCA is an **unsupervised method**, yet it reveals clear class boundaries — supporting the use of these features for classification tasks.
- This analysis can be extended by exploring more components or applying advanced classifiers.

## 🤔 Reflection on Model Utility

While the logistic regression model achieved excellent accuracy (~99%), it’s important to reflect critically on what this means:
- The dataset used in this project contains only 569 samples, which limits the robustness and generalizability of any model trained on it.
- PCA revealed that the tumor data is naturally well-structured and highly separable even in just two dimensions. This suggests that the classes (malignant vs. benign) are linearly separable to begin with — reducing the need for complex modeling.
- Therefore, the high accuracy is likely more a reflection of the clarity of the data structure than of the model’s predictive power.
In short, while this project demonstrates effective use of PCA and logistic regression, the real-world value of the model is limited due to:
- the small and clean dataset,
- strong class separability already visible through PCA,
- and the lack of messy, ambiguous data common in practical scenarios.
That said, this exercise remains valuable from a methodological and learning standpoint, demonstrating how dimensionality reduction and classification can work together when conditions are favorable.