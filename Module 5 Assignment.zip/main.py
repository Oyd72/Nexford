# Import libraries for data handling, visualization, and modeling
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

# -------------------------------
# Load and explore the dataset
# -------------------------------

# Load preprocessed breast cancer dataset from sklearn
data = load_breast_cancer()

# Convert feature data to pandas DataFrame
X = pd.DataFrame(data.data, columns=data.feature_names)

# Target labels (0 = malignant, 1 = benign)
y = pd.Series(data.target, name="target")

# Basic data summary
print("Data shape:", X.shape)  # 569 samples, 30 features
print("Target classes:", data.target_names)  # ['malignant', 'benign']
print("Missing values:", X.isnull().sum().sum())  # 0 means dataset is clean

# -------------------------------
# Standardize the data
# -------------------------------

# PCA is sensitive to feature scale, so we normalize all features to mean 0, std 1
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# -------------------------------
# Apply PCA for dimensionality reduction
# -------------------------------

# Reduce to 2 principal components
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Show the proportion of total variance explained by each component
print("Explained variance ratio:", pca.explained_variance_ratio_)

# Identify which original features contribute the most to each PCA component
# This helps label the axes more informatively
pca_components = pd.DataFrame(
    pca.components_,
    columns=data.feature_names,
    index=['PC1', 'PC2']
)

# Get top contributing features to each principal component
top_features_pc1 = pca_components.loc['PC1'].abs().sort_values(ascending=False)
top_features_pc2 = pca_components.loc['PC2'].abs().sort_values(ascending=False)

# Choose the highest-loading features as rough axis indicators
label_pc1 = top_features_pc1.index[0]
label_pc2 = top_features_pc2.index[0]

print(f"Top contributor to PC1: {label_pc1}")
print(f"Top contributor to PC2: {label_pc2}")

# -------------------------------
# Plot the PCA-reduced data
# -------------------------------

plt.figure(figsize=(8, 6))

# Use color to distinguish benign and malignant
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap='coolwarm', alpha=0.7)

# Use top contributing features as PCA axis "names"
plt.xlabel(f'PC1 (mostly {label_pc1})')
plt.ylabel(f'PC2 (mostly {label_pc2})')
plt.title('PCA: Breast Cancer Dataset')
plt.colorbar(label='Target (0 = malignant, 1 = benign)')
plt.grid(True)
plt.tight_layout()
plt.savefig("pca_scatter.png")
plt.show()

# -------------------------------
# Bonus: Logistic Regression on PCA-reduced data
# ----------------------------------------------

# Split the PCA-transformed dataset into training and testing sets
# - X_pca: 2-dimensional dataset after PCA transformation
# - y: target labels (0 = malignant, 1 = benign)
# - test_size=0.2: 20% of data goes to the test set
# - random_state=42: ensures the split is reproducible
X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.2, random_state=42)

# Initialize a logistic regression classifier
# This model will learn to distinguish between classes using the 2 principal components
logreg = LogisticRegression()

# Train (fit) the model on the training data
# The model learns the relationship between the PCA features and the class labels
logreg.fit(X_train, y_train)

# Use the trained model to predict class labels on the test set
y_pred = logreg.predict(X_test)

# Print model evaluation results
# Accuracy: overall proportion of correct predictions
# Classification report: includes precision, recall, F1-score for each class
# target_names: maps numeric labels (0 and 1) to 'malignant' and 'benign'
print("\nLogistic Regression Results (Bonus Task)")
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred, target_names=data.target_names))

# --------------------------------------
# Visualization: Decision Boundary Plot
# --------------------------------------

# Create a mesh grid over PCA feature space
x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                     np.linspace(y_min, y_max, 300))

# Predict labels across the grid to visualize decision regions
Z = logreg.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plot decision boundary with data points
plt.figure(figsize=(10, 7))
plt.contourf(xx, yy, Z, alpha=0.2, cmap='coolwarm')
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap='coolwarm', edgecolor='k', s=40)
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.title('Logistic Regression Decision Boundary (PCA Components)')
plt.colorbar(scatter, label='Target Class (0 = Malignant, 1 = Benign)')
plt.grid(True)

# Save the plot
plt.savefig("pca_logistic_boundary.png")
plt.show()