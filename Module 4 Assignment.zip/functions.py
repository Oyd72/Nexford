import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
from collections import Counter

# === Descriptive and Cleaning Functions ===
def describe_netflix_data(df, save=False):
    """
    Generates descriptive statistics and missing value summaries.
    If `save` is True, writes results to 'netflix_data_summary.txt'.
    """
    lines = []

    # Dataset dimensions
    lines.append(f"Dataset shape: {df.shape[0]} rows × {df.shape[1]} columns\n")

    # Data types
    lines.append("Column data types:\n")
    lines.append(df.dtypes.to_string())
    lines.append("\n")

    # Missing values
    lines.append("Missing values:\n")
    missing = df.isnull().sum()
    missing_percent = (missing / len(df) * 100).round(1)
    lines.append(
        pd.concat([missing, missing_percent.rename("Percent")], axis=1)
        .rename(columns={0: "Missing"})
        .to_string()
    )
    lines.append("\n")
    
    # Unique values for selected categorical columns
    for col in ['type', 'rating', 'country']:
        if col in df.columns:
            lines.append(f"Value counts for '{col}':\n")
            lines.append(df[col].value_counts().head(10).to_string())
            lines.append("\n")

    result = "\n".join(lines)

    if save:
        with open("netflix_data_summary.txt", "w", encoding="utf-8") as f:
            f.write(result)
    else:
        print(result)

def clean_netflix_data(df):
    """    
    Steps performed:
    1. Convert 'date_added' to datetime and extract 'year_added'.
    2. Fill missing values for key categorical columns with 'Unknown'.
    3. Drop rows with missing 'duration' or 'date_added'.
    4. Create missingness indicator columns for 'director' and 'cast'.
    Parameters:
        df (pd.DataFrame): Raw Netflix dataset.
    Returns:
        pd.DataFrame: Cleaned dataset.
    """
    # Convert 'date_added' to datetime and extract year
    df['date_added'] = pd.to_datetime(df['date_added'], errors='coerce')
    df['year_added'] = df['date_added'].dt.year

    # Fill missing values with 'Unknown' for categorical context columns
    df['rating'] = df['rating'].fillna('Unknown')
    df['country'] = df['country'].fillna('Unknown')
    df['listed_in'] = df['listed_in'].fillna('Unknown')
    df['director'] = df['director'].fillna('Unknown')
    df['cast'] = df['cast'].fillna('Unknown')

    # Drop records with missing 'duration' or 'date_added' (critical fields)
    df = df[df['duration'].notna()]
    df = df[df['date_added'].notna()]

    # Add missingness indicator flags for potential modeling use
    df['missing_director'] = df['director'].apply(lambda x: 1 if x == 'Unknown' else 0)
    df['missing_cast'] = df['cast'].apply(lambda x: 1 if x == 'Unknown' else 0)

    return df

# === Utility Functions ===
def get_top_genres(df, top_n=10):
    if 'listed_in' not in df.columns:
        raise ValueError("Missing 'listed_in' column.")
    all_genres = df['listed_in'].dropna().str.split(', ').sum()
    return pd.Series(Counter(all_genres)).sort_values(ascending=False).head(top_n)

# === Plotting Functions ===
def plot_top_genres(df, save=True):
    if 'listed_in' not in df.columns:
        raise ValueError("Missing 'listed_in' column.")
    
    all_genres = df['listed_in'].dropna().str.split(', ').sum()
    genre_counts = get_top_genres(df)
    
    plt.figure(figsize=(10, 6))
    sns.barplot(x=genre_counts.values, y=genre_counts.index)
    plt.title("Top 10 Most Watched Genres on Netflix")
    plt.xlabel("Count")
    plt.ylabel("Genre")
    plt.tight_layout()
    
    if save:
        plt.savefig("python_top_genres.png")
    plt.close()

def plot_duration_distribution(df, save=True):
    if 'duration_minutes' not in df.columns:
        raise ValueError("Missing 'duration_minutes' column.")
    
    plt.figure(figsize=(10, 6))
    sns.histplot(df['duration_minutes'].dropna(), bins=30, kde=True)
    plt.title("Distribution of Movie Durations")
    plt.xlabel("Duration (minutes)")
    plt.ylabel("Frequency")
    plt.tight_layout()
    
    if save:
        plt.savefig("python_movie_duration_distribution.png")
    plt.close()

def plot_titles_by_year_type(df, save=True):
    required_cols = {'year_added', 'type'}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"Missing required columns: {required_cols}")
    
    grouped = df.groupby(['year_added', 'type']).size()
    year_type_counts = grouped.unstack().fillna(0)
    
    ax = year_type_counts.plot(
        kind='bar', stacked=True, figsize=(12, 6), colormap='tab20'
    )
    ax.set_title("Movies and TV Shows Added per Year")
    ax.set_xlabel("Year")
    ax.set_ylabel("Number of Titles")
    ax.legend(title='Type')
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    if save:
        plt.savefig("python_titles_by_year_type.png")
    plt.close()

def plot_country_collaborations(df, save=True):
    if 'country' not in df.columns:
        raise ValueError("Missing 'country' column.")
    
    multi_country_rows = df[df['country'].str.contains(', ', na=False)]
    collab_counts = Counter()
    
    for countries in multi_country_rows['country'].str.split(', '):
        for i in range(len(countries)):
            for j in range(i + 1, len(countries)):
                pair = tuple(sorted([countries[i], countries[j]]))
                collab_counts[pair] += 1
    
    collab_df = pd.DataFrame(
        collab_counts.items(), columns=['Country Pair', 'Count']
    )
    top_collabs = collab_df.sort_values(
        by='Count', ascending=False
    ).head(10)
    
    plt.figure(figsize=(12, 6))
    plt.barh(
        [f"{a} & {b}" for a, b in top_collabs['Country Pair']],
        top_collabs['Count'],
        color='slateblue'
    )
    plt.xlabel("Number of Collaborations")
    plt.title("Top 10 Country Collaborations on Netflix")
    plt.gca().invert_yaxis()
    plt.grid(axis='x', linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    if save:
        plt.savefig("python_country_collaborations.png")
    plt.close()

def plot_duration_by_rating(df, save=True):
    if 'duration_minutes' not in df.columns:
        raise ValueError("Missing 'duration_minutes' column.")
    if 'rating' not in df.columns:
        raise ValueError("Missing 'rating' column.")
    
    plt.figure(figsize=(12, 6))
    sns.boxplot(data=df, x='rating', y='duration_minutes')
    plt.title("Movie Duration by Rating")
    plt.xlabel("Rating")
    plt.ylabel("Duration (minutes)")
    plt.xticks(rotation=45)
    plt.grid(True, axis='y', linestyle='--', alpha=0.5)
    plt.tight_layout()
    
    if save:
        plt.savefig("python_duration_by_rating.png")
    plt.close()

def plot_most_watched_genres(df, save=True):
    if 'listed_in' not in df.columns:
        raise ValueError("Missing 'listed_in' column.")
    
    all_genres = df['listed_in'].dropna().str.split(', ').sum()
    genre_counts = get_top_genres(df).sort_values(ascending=True)
    
    plt.figure(figsize=(10, 6))
    genre_counts.plot(kind='barh', color='coral')
    plt.title("Top 10 Most Watched Genres on Netflix")
    plt.xlabel("Count")
    plt.ylabel("Genre")
    plt.grid(axis='x', linestyle='--', alpha=0.5)
    plt.tight_layout()
    
    if save:
        plt.savefig("python_most_watched_genres.png")
    plt.close()

def plot_ratings_distribution(df, save=True):
    if 'rating' not in df.columns:
        raise ValueError("Missing 'rating' column.")
    
    plt.figure(figsize=(10, 6))
    sns.countplot(
        data=df,
        x='rating',
        order=df['rating'].value_counts().index,
        hue='rating',
        palette='Set2',
        legend=False
    )
    plt.title("Distribution of Content Ratings on Netflix")
    plt.xlabel("Rating")
    plt.ylabel("Count")
    plt.xticks(rotation=45)
    plt.grid(axis='y', linestyle='--', alpha=0.5)
    plt.tight_layout()
    
    if save:
        plt.savefig("python_ratings_distribution.png")
    plt.close()

def plot_genre_forecast(df, save=True):
    import numpy as np
    from sklearn.linear_model import LinearRegression
    
    if 'date_added' not in df.columns:
        raise ValueError("Missing 'date_added' column.")
    
    df['date_added'] = pd.to_datetime(df['date_added'], errors='coerce')
    df['year_added'] = df['date_added'].dt.year
    df = df[df['year_added'] <= 2019]
    
    df_genres = df.dropna(subset=['listed_in'])
    df_genres = df_genres.assign(
        genre_list=df_genres['listed_in'].str.split(', ')
    ).explode('genre_list')
    
    genre_year = df_genres.groupby(
        ['year_added', 'genre_list']
    ).size().reset_index(name='count')
    
    top_genres = genre_year.groupby('genre_list')['count'] \
        .sum().nlargest(5).index.tolist()
    top_data = genre_year[genre_year['genre_list'].isin(top_genres)]
    
    forecast_df = pd.DataFrame()
    for genre in top_genres:
        genre_data = top_data[top_data['genre_list'] == genre].copy()
        X = genre_data['year_added'].values.reshape(-1, 1)
        y = genre_data['count'].values
        
        model = LinearRegression()
        model.fit(X, y)
        
        future_years = np.array([2020, 2021, 2022]).reshape(-1, 1)
        future_counts = model.predict(future_years).clip(min=0).round()
        
        future_df = pd.DataFrame({
            'year_added': future_years.flatten(),
            'genre_list': genre,
            'count': future_counts.astype(int)
        })
        forecast_df = pd.concat([forecast_df, genre_data, future_df])
    
    plt.figure(figsize=(12, 6))
    for genre in top_genres:
        data = forecast_df[forecast_df['genre_list'] == genre]
        plt.plot(data['year_added'], data['count'], marker='o', label=genre)
    
    plt.title("Forecast of Top 5 Genre Popularity on Netflix (Until 2022)")
    plt.xlabel("Year")
    plt.ylabel("Count")
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.legend(title='Genre')
    plt.tight_layout()
    
    if save:
        plt.savefig("python_genre_forecast.png")
    plt.close()