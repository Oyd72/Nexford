
# 📊 Netflix Data Visualization Project

This project explores and visualizes Netflix content data using both **Python** and **R**. It includes robust data cleaning, analysis of genre and rating trends, and polished visual outputs for reporting or presentation purposes.

---

## 📁 Project Files

| File                         | Description |
|------------------------------|-------------|
| `Netflix_shows_movies.csv`   | Raw dataset of Netflix titles with metadata (e.g., type, duration, country, genres). |
| `functions.py`               | Python utility functions for cleaning and plotting data. |
| `main.py`                    | Python script to run data cleaning and plotting functions in Python. |
| `Graphs in R.r`              | R script generating 9 different plots from the same dataset. |
| `netflix_data_summary.txt`   | Automatically generated file summarizing dataset structure, missingness, and key frequencies. |
| `*.png`                      | Plot images automatically saved by both R and Python scripts. |

---

## 🧹 Data Cleaning

The `clean_netflix_data()` function in Python:
- Converts `date_added` to datetime and extracts `year_added`.
- Fills missing categorical values (e.g., `country`, `rating`, `listed_in`) with `"Unknown"`.
- Drops records missing `duration` or `date_added`.
- Adds indicator columns for missing `director` and `cast`.

---

## 🧪 Descriptive Statistics

The function `describe_netflix_data()`:
- Outputs the dataset's shape, column types, and missing values.
- Summarizes top 10 most common values for `type`, `rating`, and `country`.
- Saves output to `netflix_data_summary.txt` (automatically generated when running `main.py`).

---

## 📈 Python Visualizations

Running `main.py` saves 9 high-quality visualizations:

| Plot Filename                            | Description |
|------------------------------------------|-------------|
| `python_most_watched_genres.png`         | Horizontal bar chart of the 10 most common genres. |
| `python_ratings_distribution.png`        | Count plot of content ratings. |
| `python_movie_duration_distribution.png` | Histogram of movie durations. |
| `python_duration_by_rating.png`          | Boxplot of movie durations across ratings. |
| `python_titles_by_year_type.png`         | Stacked bar chart showing TV shows vs. movies per year. |
| `python_country_collaborations.png`      | Top 10 country collaboration pairs. |
| `python_top_genres.png`                  | Alternative vertical bar chart of top genres. |
| `python_genre_forecast.png`              | Forecast of the 5 most popular genres through 2022 using linear regression. |

---

## 📊 R Visualizations

The R script (`Graphs in R.r`) loads the same dataset and produces matching graphs with some stylistic differences. The following images are generated and saved:

| Plot Filename                     | Description |
|-----------------------------------|-------------|
| `R_most_watched_genres.png`       | Horizontal bar chart of most watched genres. |
| `R_ratings_distribution.png`      | Bar chart of rating frequency. |
| `R_movie_duration_histogram.png`  | Histogram of movie durations. |
| `R_duration_by_rating.png`        | Boxplot of duration by rating. |
| `R_titles_per_year.png`           | Year-by-year count of content types. |
| `R_country_collaborations.png`    | Top co-productions by country. |
| `R_lollipop_genres.png`           | Lollipop chart version of genre popularity. |
| `R_waffle_ratings.png`            | Waffle chart showing rating proportions. |
| `R_duration_density.png`          | Smoothed density plot of movie durations. |

---

## ✅ How to Run

### Python

1. Install dependencies:
   ```bash
   pip install pandas matplotlib seaborn scikit-learn
   ```

2. Run the script:
   ```bash
   python main.py
   ```

This will:
- Clean and describe the dataset
- Generate 9 saved `.png` plots
- Create `netflix_data_summary.txt`

All plots will be saved automatically as `.png` files.

### R

1. Make sure you have the required packages:
   ```r
   install.packages(c("ggplot2", "tidyverse", "stringr", "tidyr", "forcats", "ggsci"))
   ```

2. Run the full script in R:
   ```r
   source("Graphs in R.r")
   ```

---

## 📌 Notes

- All plots are saved in **10×10 inch** resolution at **600 DPI** for clarity.
- Colors in R and Python differ slightly to offer varied aesthetic palettes.
- This project demonstrates both **exploratory data analysis** and **statistical forecasting** using linear regression.
- Waffle chart (R) uses `ggsci::scale_fill_d3()` for high-category color support.
