library(ggplot2)
library(tidyverse)
library(stringr)
library(tidyr)
library(forcats)
library(ggsci)

# Load data
df <- read_csv("Netflix_shows_movies.csv",show_col_types = FALSE) %>%
  mutate(
    date_added = as.Date(date_added, format = "%B %d, %Y"),
    year_added = lubridate::year(date_added)
  )
# --- Prepare Top Genres ---
top_genres <- df %>%
  filter(!is.na(listed_in)) %>%
  separate_rows(listed_in, sep = ", ") %>%
  count(listed_in, sort = TRUE) %>%
  slice_max(n, n = 10)

# --- Plot 1: Most Watched Genres (Horizontal) ---
p1 <- ggplot(top_genres, aes(x = n, y = fct_reorder(listed_in, n))) +
  geom_col(fill = "coral") +
  labs(title = "Most Watched Genres", x = "Count", y = "Genre")

# --- Plot 2: Ratings Distribution ---
rating_counts <- df %>%
  count(rating, sort = TRUE)

p2 <- ggplot(rating_counts, aes(x = reorder(rating, -n), y = n)) +
  geom_col(fill = "darkolivegreen") +
  labs(title = "Distribution of Ratings", x = "Rating", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# --- Plot 3 Movie Duration Histogram ---
df_movies <- df %>%
  filter(type == "Movie", !is.na(duration)) %>%
  mutate(duration_minutes = as.numeric(str_extract(duration, "\\d+")))

p3 <- ggplot(df_movies, aes(x = duration_minutes)) +
  geom_histogram(bins = 30, fill = "skyblue", color = "white") +
  labs(title = "Distribution of Movie Durations", x = "Duration (minutes)",
       y = "Frequency")

# --- Plot 4: Movie Duration by Rating ---
p4 <- ggplot(df_movies, aes(x = rating, y = duration_minutes)) +
  geom_boxplot(fill = "plum") +
  labs(title = "Movie Duration by Rating", x = "Rating",
       y = "Duration (minutes)") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# --- Plot 5: Titles per Year by Type ---
year_type_counts <- df %>%
  filter(!is.na(year_added)) %>%
  count(year_added, type)

p5 <- ggplot(year_type_counts, aes(x = year_added, y = n, fill = type)) +
  geom_col(position = "stack") +
  labs(title = "Titles per Year by Type", x = "Year",
       y = "Number of Titles")

# --- Plot 6: Country Collaborations ---
collab_counts <- df %>%
  filter(str_detect(country, ", ")) %>%
  pull(country) %>%
  str_split(", ") %>%
  map(~ combn(sort(.x), 2, simplify = FALSE)) %>%
  unlist(recursive = FALSE) %>%
  map_chr(~ paste(.x, collapse = " & ")) %>%
  table() %>%
  sort(decreasing = TRUE) %>%
  head(10) %>%
  as.data.frame()

colnames(collab_counts) <- c("CountryPair", "Count")

p6 <- ggplot(collab_counts, aes(x = Count,
                                y = reorder(CountryPair, Count))) +
  geom_col(fill = "darkslateblue") +
  labs(title = "Top 10 Country Collaborations", x = "Count",
       y = "Country Pair")

# --- Plot 7: Lollipop Chart for Most Watched Genres ---
p7 <- ggplot(top_genres, aes(x = n, y = fct_reorder(listed_in, n))) +
  geom_segment(aes(x = 0, xend = n, y = fct_reorder(listed_in, n),
                   yend = fct_reorder(listed_in, n)),
               color = "gray70", linewidth = 1) +
  geom_point(color = "coral", size = 4) +
  labs(title = "Most Watched Genres", x = "Count", y = "Genre")

# --- Plot 8: Waffle Chart for Ratings Distribution ---
rating_counts <- df %>%
  count(rating) %>%
  mutate(prop = n / sum(n), tiles = round(prop * 100)) %>%
  arrange(desc(prop)) %>%
  mutate(rating = factor(rating, levels = unique(rating)))

waffle_df <- rating_counts %>%
  uncount(tiles) %>%
  mutate(index = row_number() - 1,
         row = 9 - index %/% 10,
         col = index %% 10)

p8 <- ggplot(waffle_df, aes(x = col, y = row, fill = rating)) +
  geom_tile(color = "white") +
  coord_equal() +
  theme_void() +
  theme(
    legend.position = "bottom",
    legend.title = element_text(color = "white", size = 10),
    legend.text = element_text(color = "white", size = 9),
    plot.title = element_text(color = "white", hjust = 0.5, size = 14),
    plot.subtitle = element_text(color = "white", hjust = 0.5, size = 10),
    plot.caption = element_text(color = "gray80", hjust = 0.5, size = 8),
    plot.background = element_rect(fill = "black", color = NA),
    legend.key.size = unit(0.6, "cm"),
    legend.spacing.x = unit(0.5, "cm")
  ) +
  scale_fill_d3(palette = "category20") +
  guides(fill = guide_legend(title = "Rating", nrow = 2)) +
  labs(
    title = "Netflix Ratings Distribution",
    subtitle = "Waffle chart (1 square = 1%)",
    caption = "Source: Netflix dataset",
    fill = "Rating"
  )

# --- Plot 9: Density Plot for Distribution of Movie Durations ---
p9 <- ggplot(df_movies, aes(x = duration_minutes)) +
  geom_density(fill = "lightblue", alpha = 0.6,
               color = "steelblue", size = 1) +
  labs(title = "Smoothed Distribution of Movie Durations",
       x = "Duration (minutes)", y = "Density")

# Save all plots
all_plots <- list(
  R_most_watched_genres = p1,
  R_ratings_distribution = p2,
  R_movie_duration_histogram = p3,
  R_duration_by_rating = p4,
  R_titles_per_year = p5,
  R_country_collaborations = p6,
  R_lollipop_genres = p7,
  R_waffle_ratings = p8,
  R_duration_density = p9
)

walk2(all_plots, names(all_plots), ~ ggsave(
  filename = paste0(.y, ".png"),
  plot = .x,
  width = 10,
  height = 10,
  units = "in",
  dpi = 600
))