import pandas as pd
from functions import (
    clean_netflix_data, plot_top_genres, plot_duration_distribution,
    plot_titles_by_year_type, plot_country_collaborations,
    plot_duration_by_rating, plot_most_watched_genres, plot_ratings_distribution,
    plot_genre_forecast, describe_netflix_data
)

if __name__ == "__main__":
    # Load and clean data
    df_raw = pd.read_csv("Netflix_shows_movies.csv")
    describe_netflix_data(df_raw, save=True)
    df = clean_netflix_data(df_raw)

    # Extract duration for movies
    df_movies = df[df['type'] == 'Movie'].copy()
    df_movies['duration_minutes'] = df_movies['duration'].str.extract(r'(\d+)').astype(float)

    # Generate and save visualizations
    plot_most_watched_genres(df, save=True)
    plot_ratings_distribution(df, save=True)
    plot_duration_distribution(df_movies, save=True)
    plot_duration_by_rating(df_movies, save=True)
    plot_titles_by_year_type(df, save=True)
    plot_country_collaborations(df, save=True)
    plot_genre_forecast(df, save=True)
