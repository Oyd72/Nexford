# 🧾 Employee Profile Exporter

A lightweight, interactive Python tool to search, preview, and export salary profiles for San Francisco employees (2011–2018). Built using Kaggle’s public dataset and `pandas`.

---

## ✨ Features

- 📥 Automatically downloads the dataset from Kaggle (if not cached)
- 🔍 Supports wildcard search queries (e.g., `*FORD`, `JOHN*`, `*LEE*`)
- 👁️ Optional preview of matched records (all or paginated)
- 📤 Exports search results as individual CSVs
- 🗜️ Bundles exported profiles into a ZIP file: `Employee Profiles.zip`
- 🧠 Uses pickle-based caching for faster repeated lookups
- 📊 Includes an R script to unzip and display the exported data

---

## 📁 Project Structure

```bash
EmployeeProfileExporter/
├── Assignment_Module_2.py         # 💡 Main Python script
├── display_profiles.R             # 📄 R script for unzipping and displaying output
├── README.md                      # 📄 Project description & usage
├── requirements.txt               # 📦 Dependencies
├── sf_salaries/                   # 📂 Cached data + dictionary
│   ├── Total.csv
│   └── employee_dict.pkl
├── Employee Profile/             # 📑 Exported employee CSVs
├── Employee Profiles.zip         # 🧳 Final export archive
└── .gitignore                     # 🔒 Ignored files/folders
```

---

## 📦 Installation

Install required packages with:

```bash
pip install -r requirements.txt
```

### `requirements.txt`
```txt
pandas
kaggle
```

💡 You must have a [Kaggle API token](https://www.kaggle.com/docs/api) (`kaggle.json`) set up in `~/.kaggle/` or via environment variables.

---

## ▶️ Usage

Launch the tool:
```bash
python Assignment_Module_2.py
```

### 🔁 Example Session
```text
Employee Name Pattern: *FORD
Found 57 matching records.
View results before export? (y/n): y
Show all or in batches of 20? (all/20): 20
... [paged preview] ...
Zipping records to Employee Profiles.zip
```

To view the exported data in **R**, run:
```r
unzip("Employee Profiles.zip", exdir = "Employee Profile")
data <- list.files("Employee Profile", full.names = TRUE)
lapply(data, read.csv)
```

---

## 🧹 Notes

- The cache file (`employee_dict.pkl`) accelerates repeated searches.
- Old CSVs in `Employee Profile/` are cleared before each export.
- All export output is bundled into `Employee Profiles.zip`, overwriting any previous archive.

---

## 📜 License

This project is licensed under the MIT License. See [LICENSE](LICENSE).

---

## 👩‍💻 Author

Built by **Eszter Arato** for an academic assignment. For questions, reach out via your student portal or linked repository.
