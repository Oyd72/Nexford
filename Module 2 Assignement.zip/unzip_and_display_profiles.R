# Set working directory to where the ZIP file is located
setwd("C:/Users/oyd21/AppData/Local/Programs/Python/Python313")

# Unzip the archive to a folder named "Employee Profile"
unzip("Employee Profiles.zip", exdir = "Employee Profile")

# List CSV files inside the extracted folder
csv_files <- list.files("Employee Profile", full.names = TRUE, pattern = "\\.csv$")

# Read all CSVs into a list of data frames
profiles <- lapply(csv_files, read.csv)

# Optional: display the first one
print(profiles[[1]])
