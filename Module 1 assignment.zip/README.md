# Worker Payment Generator

## Overview
This project simulates weekly payment processing for 400 employees at Highridge Construction Company using both Python and R.

## Files
- `worker_payments.py`: Python script generating worker data and payment slips.
- `worker_payments.R`: R script equivalent of the Python version.
- `README.md`: This file.

## How to Run

### Python
1. Ensure Python 3 is installed.
2. Run the script:
   ```bash
   python worker_payments.py
   ```

### R
1. Ensure R is installed.
2. Run the script in R:
   ```R
   source("worker_payments.R")
   ```

## Features
- Generates 400 workers with random gender and salary.
- Applies conditional rules for assigning employee levels.
- Handles errors gracefully in both Python and R.

## Author
Eszter Arato for Nexford University assignment
