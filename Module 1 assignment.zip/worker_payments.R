# R Script: Worker Payment Generator
# Author: Eszter
# Purpose: Generate weekly payment slips for 400 workers at Highridge Construction

set.seed(42)  # For reproducibility

# Step 1: Generate workers
names <- paste0("Worker_", 1:400)
genders <- sample(c("Male", "Female"), 400, replace = TRUE)
salaries <- sample(5000:30000, 400, replace = TRUE)

# Step 2: Create workers data frame
workers <- data.frame(
  name = names,
  gender = genders,
  salary = salaries,
  stringsAsFactors = FALSE
)

# Step 3: Generate payment slips with logic and error handling
for (i in 1:nrow(workers)) {
  tryCatch({
    level <- ""

    if (workers$salary[i] > 10000 && workers$salary[i] < 20000) {
      level <- "A1"
    }
    if (workers$salary[i] > 7500 && workers$salary[i] < 30000 && workers$gender[i] == "Female") {
      level <- "A5-F"
    }

    message <- sprintf(
      "%s: $%d | Gender: %s | Level: %s",
      workers$name[i], workers$salary[i], workers$gender[i], level
    )

    print(message)
  }, error = function(e) {
    print(paste("Error processing", workers$name[i], ":", e$message))
  })
}
