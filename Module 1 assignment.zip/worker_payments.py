import random

# Step 1: Generate workers
genders = ['Male', 'Female']
names = [f"Worker_{i+1}" for i in range(400)]
workers = []

for name in names:
    worker = {
        'name': name,
        'gender': random.choice(genders),
        'salary': random.randint(5000, 30000)
    }
    workers.append(worker)

# Step 2: Generate payment slips with logic and exception handling
for worker in workers:
    try:
        level = ""
        if 10000 < worker['salary'] < 20000:
            level = "A1"
        if 7500 < worker['salary'] < 30000 and worker['gender'] == 'Female':
            level = "A5-F"

        print(f"{worker['name']}: ${worker['salary']} | Gender: {worker['gender']} | Level: {level}")

    except Exception as e:
        print(f"Error processing {worker['name']}: {e}")
